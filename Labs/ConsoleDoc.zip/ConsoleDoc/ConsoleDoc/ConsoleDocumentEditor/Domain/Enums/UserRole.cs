﻿namespace ConsoleDoc.ConsoleDocumentEditor.Domain.Enums;

public enum UserRole
{
    Viewer,
    Editor,
    Administrator
}