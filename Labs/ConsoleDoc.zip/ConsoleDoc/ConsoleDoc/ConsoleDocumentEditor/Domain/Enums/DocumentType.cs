﻿namespace ConsoleDoc.ConsoleDocumentEditor.Domain.Enums;

public enum DocumentType
{
    PlainText,
    Markdown,
    RichText,
    Json,
    Xml
}