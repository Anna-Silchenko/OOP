﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Domain;
using DataAccess;
using ExternalAPI;

namespace MyProject.Tests
{
    // In-memory реализация репозитория для тестов.
    public class InMemoryStudentRepository : IStudentRepository
    {
        private readonly List<Student> _students = new List<Student>();

        public void AddStudent(Student student)
        {
            _students.Add(student);
        }

        public void UpdateStudent(Student student)
        {
            // Обновление не требуется — объект обновляется по ссылке.
        }

        public List<Student> GetAllStudents()
        {
            return _students;
        }
    }

    // Фиктивный адаптер для возврата тестовой цитаты без вызова реального API.
    public class FakeQuoteApiAdapter : IQuoteApiAdapter
    {
        public Task<QuoteDTO> GetRandomQuoteAsync()
        {
            return Task.FromResult(QuoteDTO.Create("Test Quote", "Test Author"));
        }
    }
}
