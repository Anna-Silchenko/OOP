﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Linq;
using System.Threading.Tasks;
using Application;
using Domain;
using DataAccess;
using ExternalAPI;

namespace MyProject.Tests
{
    [TestClass]
    public class StudentServiceTests
    {
        private StudentService _studentService;

        [TestInitialize]
        public void Setup()
        {
            // Используем in-memory репозиторий и фиктивный адаптер для тестирования.
            IStudentRepository repository = new InMemoryStudentRepository();
            IQuoteApiAdapter fakeQuoteAdapter = new FakeQuoteApiAdapter();
            _studentService = new StudentService(repository, fakeQuoteAdapter);
        }

        [TestMethod]
        public async Task AddStudent_ValidData_ReturnsStudentAndQuote()
        {
            // Arrange
            var dto = new StudentDTO { Name = "Test Student", Grade = 8.5 };

            // Act
            var result = await _studentService.AddStudentAsync(dto);

            // Assert
            Assert.IsNotNull(result.student, "Студент не должен быть null.");
            Assert.AreEqual("Test Student", result.student.Name);
            Assert.AreEqual(8.5, result.student.Grade);
            Assert.IsNotNull(result.quote, "Цитата не должна быть null.");
            Assert.AreEqual("Test Quote", result.quote.Content);
            Assert.AreEqual("Test Author", result.quote.Author);
        }

        [TestMethod]
        [ExpectedException(typeof(Exception))]
        public async Task AddStudent_InvalidGrade_ThrowsException()
        {
            // Arrange: отрицательная оценка недопустима.
            var dto = new StudentDTO { Name = "Invalid Student", Grade = -1 };

            // Act: ожидаем выброс исключения.
            await _studentService.AddStudentAsync(dto);
        }

        [TestMethod]
        public async Task EditStudent_ValidData_UpdatesStudent()
        {
            // Arrange: добавляем студента.
            var dto = new StudentDTO { Name = "Original Name", Grade = 7.0 };
            var result = await _studentService.AddStudentAsync(dto);
            Guid studentId = result.student.Id;

            // Act: редактируем данные студента.
            _studentService.EditStudent(studentId, "Updated Name", 9.5);
            var students = _studentService.GetAllStudents();
            var updatedStudent = students.FirstOrDefault(s => s.Id == studentId);

            // Assert
            Assert.IsNotNull(updatedStudent, "После редактирования студент должен существовать.");
            Assert.AreEqual("Updated Name", updatedStudent.Name);
            Assert.AreEqual(9.5, updatedStudent.Grade);
        }
    }
}
