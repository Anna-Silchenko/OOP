﻿using System;
using System.Threading.Tasks;
using DataAccess;
using ExternalAPI;
using Application;
using Presentation;

class Program
{
    static async Task Main(string[] args)
    {
        var repository = new StudentRepository();
        var quoteAdapter = new QuoteApiAdapter();
        var studentService = new StudentService(repository, quoteAdapter);
        var ui = new ConsoleUI(studentService);

        Console.WriteLine("Система управления записями учащихся");
        Console.WriteLine("Автор: Сильченко Анна, Группа 353504");
        await ui.Run();
    }
}
