﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Domain;
using DataAccess;
using ExternalAPI;

namespace Application
{
    public class StudentService
    {
        private readonly IStudentRepository _repository;
        private readonly IQuoteApiAdapter _quoteAdapter;

        // Теперь принимаем IStudentRepository вместо StudentRepository
        public StudentService(IStudentRepository repository, IQuoteApiAdapter quoteAdapter)
        {
            _repository = repository;
            _quoteAdapter = quoteAdapter;
        }

        public async Task<(Student student, QuoteDTO quote)> AddStudentAsync(StudentDTO dto)
        {
            Student student;
            try
            {
                student = Student.Create(dto);
            }
            catch (Exception ex)
            {
                throw new Exception("Ошибка создания студента: " + ex.Message);
            }

            _repository.AddStudent(student);
            QuoteDTO quote = await _quoteAdapter.GetRandomQuoteAsync();
            return (student, quote);
        }

        public void EditStudent(Guid studentId, string newName, double newGrade)
        {
            var students = _repository.GetAllStudents();
            var student = students.Find(s => s.Id == studentId);
            if (student != null)
            {
                student.Edit(newName, newGrade);
                _repository.UpdateStudent(student);
            }
            else
            {
                throw new Exception("Студент не найден.");
            }
        }

        public List<Student> GetAllStudents() => _repository.GetAllStudents();
    }
}
