﻿using System;
using System.Threading.Tasks;
using Application;

namespace Commands
{
    public class ViewStudentsCommand : ICommand
    {
        private readonly StudentService _studentService;

        public ViewStudentsCommand(StudentService studentService)
        {
            _studentService = studentService;
        }

        public async Task Execute()
        {
            var students = _studentService.GetAllStudents();
            Console.WriteLine("Список студентов:");
            foreach (var student in students)
            {
                Console.WriteLine(student);
            }
            await Task.CompletedTask;
        }
    }
}
