﻿using System.Threading.Tasks;

namespace Commands
{
    public interface ICommand
    {
        Task Execute();
    }
}
