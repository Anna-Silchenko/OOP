﻿using System;
using System.Threading.Tasks;
using Application;
using Domain;

namespace Commands
{
    public class AddStudentCommand : ICommand
    {
        private readonly StudentService _studentService;

        public AddStudentCommand(StudentService studentService)
        {
            _studentService = studentService;
        }

        public async Task Execute()
        {
            Console.Write("Введите имя студента: ");
            // Используем оператор !, чтобы указать, что значение не будет null.
            string name = Console.ReadLine()!;

            Console.Write("Введите оценку студента: ");
            // Также используем ! для строки ввода оценки.
            string gradeInput = Console.ReadLine()!;
            if (!double.TryParse(gradeInput, out double grade))
            {
                Console.WriteLine("Неверно введена оценка.");
                return;
            }

            var dto = new StudentDTO { Name = name, Grade = grade };
            try
            {
                var result = await _studentService.AddStudentAsync(dto);
                Console.WriteLine("Студент успешно добавлен:");
                Console.WriteLine(result.student);
                Console.WriteLine("Мотивационная цитата:");
                Console.WriteLine(result.quote);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Ошибка: " + ex.Message);
            }
        }
    }
}
