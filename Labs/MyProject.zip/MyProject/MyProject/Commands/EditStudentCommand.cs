﻿using System;
using System.Threading.Tasks;
using Application;

namespace Commands
{
    public class EditStudentCommand : ICommand
    {
        private readonly StudentService _studentService;
        public EditStudentCommand(StudentService studentService)
        {
            _studentService = studentService;
        }

        public async Task Execute()
        {
            Console.Write("Введите ID студента для редактирования: ");
            string input = Console.ReadLine()!;
            if (!Guid.TryParse(input, out Guid studentId))
            {
                Console.WriteLine("Неверный формат ID.");
                return;
            }
            Console.Write("Новое имя студента: ");
            string newName = Console.ReadLine()!;
            Console.Write("Новая оценка студента: ");
            string gradeInput = Console.ReadLine()!;
            if (!double.TryParse(gradeInput, out double newGrade))
            {
                Console.WriteLine("Неверно введена оценка.");
                return;
            }
            try
            {
                _studentService.EditStudent(studentId, newName, newGrade);
                Console.WriteLine("Студент успешно изменен.");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Ошибка: " + ex.Message);
            }
            await Task.CompletedTask;
        }
    }
}
