﻿using System.Collections.Generic;
using Domain;

namespace DataAccess
{
    public interface IStudentRepository
    {
        void AddStudent(Student student);
        void UpdateStudent(Student student);
        List<Student> GetAllStudents();
    }
}
