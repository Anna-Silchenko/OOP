﻿using System.Collections.Generic;
using System.IO;
using System.Text.Json;
using Domain;

namespace DataAccess
{
    public class StudentRepository : IStudentRepository
    {
        // Если необходимо, можно использовать абсолютный путь или использовать Path.Combine(System.Environment.CurrentDirectory, "students.json")
        private readonly string _filePath = "students.json";
        private List<Student> _students;

        public StudentRepository()
        {
            _students = LoadStudents();
        }

        // Загрузка студентов из файла JSON при старте приложения.
        private List<Student> LoadStudents()
        {
            if (!File.Exists(_filePath))
                return new List<Student>();

            try
            {
                string json = File.ReadAllText(_filePath);
                var options = new JsonSerializerOptions
                {
                    PropertyNameCaseInsensitive = true
                };
                return JsonSerializer.Deserialize<List<Student>>(json, options) ?? new List<Student>();
            }
            catch
            {
                return new List<Student>();
            }
        }

        // Сохранение студентов в файл JSON.
        private void SaveStudents()
        {
            var options = new JsonSerializerOptions
            {
                WriteIndented = true
            };
            string json = JsonSerializer.Serialize(_students, options);
            File.WriteAllText(_filePath, json);
        }

        public void AddStudent(Student student)
        {
            _students.Add(student);
            SaveStudents();
        }

        public void UpdateStudent(Student student)
        {
            // Для простоты обновление производим глобально – можно доработать замену по Id.
            SaveStudents();
        }

        public List<Student> GetAllStudents()
        {
            return _students;
        }
    }
}
