﻿using System;
using System.Text.Json.Serialization;

namespace Domain
{
    public class Student
    {
        [JsonInclude]
        public Guid Id { get; private set; } = Guid.NewGuid();

        [JsonInclude]
        public string Name { get; private set; }

        [JsonInclude]
        public double Grade { get; private set; }

        // Пустой конструктор для десериализации.
        [JsonConstructor]
        public Student() { }

        private Student(string name, double grade)
        {
            if (string.IsNullOrWhiteSpace(name))
                throw new ArgumentException("Имя студента не может быть пустым.");
            if (grade < 0)
                throw new ArgumentException("Оценка не может быть отрицательной.");

            Name = name;
            Grade = grade;
        }

        // Фабричный метод для создания студента из DTO.
        public static Student Create(StudentDTO dto)
        {
            return new Student(dto.Name, dto.Grade);
        }

        // Метод редактирования данных студента.
        public void Edit(string newName, double newGrade)
        {
            if (string.IsNullOrWhiteSpace(newName))
                throw new ArgumentException("Имя студента не может быть пустым.");
            if (newGrade < 0)
                throw new ArgumentException("Оценка не может быть отрицательной.");

            Name = newName;
            Grade = newGrade;
        }

        public override string ToString()
        {
            return $"ID: {Id} | Имя: {Name} | Оценка: {Grade}";
        }
    }

    public class StudentDTO
    {
        public string Name { get; set; }
        public double Grade { get; set; }
    }

    public class QuoteDTO
    {
        public string Content { get; set; }
        public string Author { get; set; }

        public static QuoteDTO Create(string content, string author)
        {
            return new QuoteDTO { Content = content, Author = author };
        }

        public override string ToString()
        {
            return $"\"{Content}\" - {Author}";
        }
    }
}
