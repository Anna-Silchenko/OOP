﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Application;
using Commands;

namespace Presentation
{
    public class ConsoleUI
    {
        private readonly Dictionary<string, ICommand> _commands;

        public ConsoleUI(StudentService studentService)
        {
            _commands = new Dictionary<string, ICommand>
            {
                { "1", new AddStudentCommand(studentService) },
                { "2", new EditStudentCommand(studentService) },
                { "3", new ViewStudentsCommand(studentService) }
            };
        }

        public async Task Run()
        {
            while (true)
            {
                Console.WriteLine("\nВыберите операцию:");
                Console.WriteLine("1 - Добавить студента");
                Console.WriteLine("2 - Редактировать студента");
                Console.WriteLine("3 - Просмотреть список студентов");
                Console.WriteLine("0 - Выход");
                Console.Write("Ваш выбор: ");

                string choice = Console.ReadLine();
                if (choice == "0")
                    break;

                if (_commands.ContainsKey(choice))
                    await _commands[choice].Execute();
                else
                    Console.WriteLine("Неверный выбор, попробуйте снова.");
            }
        }
    }
}
