﻿using System.Threading.Tasks;
using Domain;

namespace ExternalAPI
{
    public interface IQuoteApiAdapter
    {
        Task<QuoteDTO> GetRandomQuoteAsync();
    }
}
