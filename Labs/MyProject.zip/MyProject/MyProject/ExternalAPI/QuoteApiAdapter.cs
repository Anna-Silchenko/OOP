﻿using System.Net.Http;
using System.Net;
using System.Text.Json;
using System.Threading.Tasks;
using Domain;

namespace ExternalAPI
{
    public class QuoteApiAdapter : IQuoteApiAdapter
    {
        private readonly HttpClient _httpClient;

        public QuoteApiAdapter()
        {
            // Обеспечиваем использование протокола TLS 1.2.
            System.Net.ServicePointManager.SecurityProtocol = System.Net.SecurityProtocolType.Tls12;

            // Создаем HttpClient с обработчиком, отключающим проверку сертификатов.
            var handler = new HttpClientHandler
            {
                // Отключение проверки сертификата для отладки (не использовать в продакшене)
                ServerCertificateCustomValidationCallback = HttpClientHandler.DangerousAcceptAnyServerCertificateValidator
            };
            _httpClient = new HttpClient(handler);
        }

        public async Task<QuoteDTO> GetRandomQuoteAsync()
        {
            string url = "https://api.quotable.io/random";
            HttpResponseMessage response = await _httpClient.GetAsync(url);
            if (response.IsSuccessStatusCode)
            {
                string json = await response.Content.ReadAsStringAsync();
                using var doc = JsonDocument.Parse(json);
                string content = doc.RootElement.GetProperty("content").GetString();
                string author = doc.RootElement.GetProperty("author").GetString();
                return QuoteDTO.Create(content, author);
            }
            else
            {
                // Резервный вариант при ошибке API.
                return QuoteDTO.Create("Stay motivated and keep pushing!", "Unknown");
            }
        }
    }
}
